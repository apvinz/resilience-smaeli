import React, { createContext, useContext, useState, useEffect } from "react";
import { defaultData, ClassData, Achievement, Member } from "../data/defaultData";
import { getItem, setItem, getClassKey, cleanSubclassCode } from "../utils/storage";
import { useAuth } from "./AuthContext";

export interface ToastState {
  show: boolean;
  message: string;
  type: "success" | "error";
}

export interface DataContextType {
  editMode: boolean;
  setEditMode: (val: boolean) => void;
  // Global Logos
  logoSekolah: string;
  setLogoSekolah: (val: string) => void;
  logoAngkatan: string;
  setLogoAngkatan: (val: string) => void;
  // Generation Page States
  generationBg: string;
  setGenerationBg: (val: string) => void;
  generationPortrait: string;
  setGenerationPortrait: (val: string) => void;
  generationHero: { title: string; subtitle: string; info: string; leaderboardTitle?: string; leaderboardSubtitle?: string };
  setGenerationHero: (val: { title: string; subtitle: string; info: string; leaderboardTitle?: string; leaderboardSubtitle?: string }) => void;
  generationDocs: { id: string; url: string; caption?: string }[];
  setGenerationDocs: (val: { id: string; url: string; caption?: string }[]) => void;
  generationAchievements: Achievement[];
  setGenerationAchievements: (val: Achievement[]) => void;

  // Class Page Dynamic States
  classLogos: Record<string, string>;
  setClassLogo: (subclass: string, base64: string) => void;
  classBgs: Record<string, string>;
  setClassBg: (subclass: string, base64: string) => void;
  classesData: Record<string, ClassData>;
  updateClassData: (subclass: string, data: Partial<ClassData>) => void;

  // Actions
  saveChanges: () => void;
  discardChanges: () => void;
  toast: ToastState;
  showToast: (msg: string, type?: "success" | "error") => void;
  hideToast: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

// Core default placeholder logos
const DEFAULT_LOGO_SEKOLAH = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='48' fill='%232B7FFF'/><polygon points='50,18 78,35 78,65 50,82 22,65 22,35' fill='%23FFFFFF' opacity='0.2'/><path d='M50,25 L72,38 L72,62 L50,75 L28,62 L28,38 Z' fill='none' stroke='%23FFFFFF' stroke-width='4'/><path d='M50,32 L66,42 L58,58 L42,58 L34,42 Z' fill='%23F5A623'/><circle cx='50' cy='48' r='5' fill='%23FFFFFF'/></svg>";
const DEFAULT_LOGO_ANGKATAN = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><circle cx='50' cy='50' r='48' fill='%231A202C'/><circle cx='50' cy='50' r='43' fill='none' stroke='%23F5A623' stroke-width='2'/><text x='50' y='58' font-family='Plus Jakarta Sans, sans-serif' font-weight='800' font-size='22' fill='%23FFFFFF' text-anchor='middle'>R21</text><path d='M30,70 Q50,60 70,70' stroke='%232B7FFF' stroke-width='3' fill='none'/></svg>";
const DEFAULT_LOGO_CLASS = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><rect width='100' height='100' rx='50' fill='%23EEF2F8'/><text x='50' y='58' font-family='sans-serif' font-weight='bold' font-size='24' fill='%232B7FFF' text-anchor='middle'>CLS</text></svg>";

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAdmin } = useAuth();
  const [editModeState, setEditModeState] = useState<boolean>(false);

  const editMode = editModeState && isAdmin;

  const setEditMode = (val: boolean) => {
    if (val && !isAdmin) {
      setEditModeState(false);
      return;
    }
    setEditModeState(val);
  };

  useEffect(() => {
    if (!isAdmin) {
      setEditModeState(false);
    }
  }, [isAdmin]);

  // Core state matching localStorage requirements
  const [logoSekolah, setLogoSekolahState] = useState<string>("");
  const [logoAngkatan, setLogoAngkatanState] = useState<string>("");
  const [generationBg, setGenerationBgState] = useState<string>("");
  const [generationPortrait, setGenerationPortraitState] = useState<string>("");
  const [generationHero, setGenerationHeroState] = useState<{ title: string; subtitle: string; info: string; leaderboardTitle?: string; leaderboardSubtitle?: string }>({ title: "", subtitle: "", info: "" });
  const [generationDocs, setGenerationDocsState] = useState<{ id: string; url: string; caption?: string }[]>([]);
  const [generationAchievements, setGenerationAchievementsState] = useState<Achievement[]>([]);

  // Multi-class dynamic parameters
  const [classLogos, setClassLogosState] = useState<Record<string, string>>({});
  const [classBgs, setClassBgsState] = useState<Record<string, string>>({});
  const [classesData, setClassesDataState] = useState<Record<string, ClassData>>({});

  // Toast status
  const [toast, setToast] = useState<ToastState>({ show: false, message: "", type: "success" });

  const showToast = (message: string, type: "success" | "error" = "success") => {
    setToast({ show: true, message, type });
  };

  const hideToast = () => {
    setToast(prev => ({ ...prev, show: false }));
  };

  // Auto Dismiss Toast
  useEffect(() => {
    if (toast.show) {
      const timer = setTimeout(() => {
        hideToast();
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [toast.show]);

  // Load Initial Data
  const loadFromStorage = () => {
    // 1. Logo Sekolah
    const storedLogoSekolah = getItem("logo_sekolah");
    setLogoSekolahState(storedLogoSekolah || DEFAULT_LOGO_SEKOLAH);

    // 2. Logo Angkatan
    const storedLogoAngkatan = getItem("logo_angkatan");
    setLogoAngkatanState(storedLogoAngkatan || DEFAULT_LOGO_ANGKATAN);

    // 3. Generation Background
    const storedGenBg = getItem("bg_generation_hero");
    setGenerationBgState(storedGenBg || "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=1600&auto=format&fit=crop");

    // 3b. Generation Portrait
    const storedGenPortrait = getItem("generation_portrait");
    setGenerationPortraitState(storedGenPortrait || "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?q=80&w=800&auto=format&fit=crop");

    // 4. Generation Hero Texts
    const storedGenHeroText = getItem("generation_hero_text");
    setGenerationHeroState(storedGenHeroText || {
      title: defaultData.generationHero.title,
      subtitle: defaultData.generationHero.subtitle,
      info: defaultData.generationHero.info,
      leaderboardTitle: defaultData.generationHero.leaderboardTitle,
      leaderboardSubtitle: defaultData.generationHero.leaderboardSubtitle
    });

    // 5. Generation Docs Photos
    const storedDocs = getItem("generation_docs");
    setGenerationDocsState(storedDocs || defaultData.documentation.photos);

    // 6. Generation Achievements
    const storedAchievements = getItem("generation_achievements");
    setGenerationAchievementsState(storedAchievements || defaultData.generationAchievements);

    // Load Class specific resources for all subclasses listed in defaultData.classes
    const tempLogos: Record<string, string> = {};
    const tempBgs: Record<string, string> = {};
    const tempClassData: Record<string, ClassData> = {};

    const allSubclasses: string[] = [];
    Object.values(defaultData.classes).forEach(obj => {
      allSubclasses.push(...obj.subclasses);
    });

    allSubclasses.forEach(subclass => {
      // dynamic local storage load keys
      const stripped = cleanSubclassCode(subclass);
      const logoKey = `logo_class_${stripped}`;
      const bgKey = `bg_class_${stripped}_hero`;
      const dataKey = `class_data_${stripped}`;

      // a. Logo
      tempLogos[subclass] = getItem(logoKey) || DEFAULT_LOGO_CLASS;

      // b. Background
      tempBgs[subclass] = getItem(bgKey) || "https://images.unsplash.com/photo-1498243691581-b145c3f54a5c?q=80&w=1600&auto=format&fit=crop";

      // c. Full payload template fallback
      const storedData = getItem(dataKey);
      let classData: ClassData;
      if (storedData) {
        classData = storedData;
      } else if ((defaultData.classDataDefaults as any)[subclass]) {
        classData = { ...(defaultData.classDataDefaults as any)[subclass] };
      } else {
        // dynamic generate template
        classData = {
          tagline: subclass === "X.1" ? "(R1VASTRA)" : `(${subclass.replace('.', '')}FORCE)`,
          slogan: `Selamat datang di ruang belajar ${subclass}. Menjunjung tinggi kebersamaan, sinergi, dan prestasi hebat.`,
          structure: {
            wali: { name: "Wali Kelas", photo: "" },
            ketua: { name: "Ketua Kelas", photo: "" },
            wakilKetua: { name: "Wakil Ketua", photo: "" },
            bendahara: { name: "Bendahara", photo: "" },
            wakilBendahara: { name: "Wakil Bendahara", photo: "" },
            sekretaris: { name: "Sekretaris", photo: "" },
            wakilSekretaris: { name: "Wakil Sekretaris", photo: "" }
          },
          members: [
            { id: "1", name: "Siswa 1", photo: "" },
            { id: "2", name: "Siswa 2", photo: "" },
            { id: "3", name: "Siswa 3", photo: "" }
          ],
          achievements: []
        };
      }

      // Check if isAvailable is defined. If not, set based on class grade
      if (classData.isAvailable === undefined) {
        if (subclass.startsWith("XI.") || subclass.startsWith("XII.")) {
          classData.isAvailable = false; // by default unavailable for XI and XII
        } else {
          classData.isAvailable = true;  // X is available by default
        }
      }

      tempClassData[subclass] = classData;
    });

    setClassLogosState(tempLogos);
    setClassBgsState(tempBgs);
    setClassesDataState(tempClassData);
  };

  useEffect(() => {
    loadFromStorage();
  }, []);

  const setLogoSekolah = (val: string) => setLogoSekolahState(val);
  const setLogoAngkatan = (val: string) => setLogoAngkatanState(val);
  const setGenerationBg = (val: string) => setGenerationBgState(val);
  const setGenerationPortrait = (val: string) => setGenerationPortraitState(val);
  const setGenerationHero = (val: { title: string; subtitle: string; info: string; leaderboardTitle?: string; leaderboardSubtitle?: string }) => setGenerationHeroState(val);
  const setGenerationDocs = (val: { id: string; url: string; caption?: string }[]) => setGenerationDocsState(val);
  const setGenerationAchievements = (val: Achievement[]) => setGenerationAchievementsState(val);

  const setClassLogo = (subclass: string, base64: string) => {
    setClassLogosState(prev => ({ ...prev, [subclass]: base64 }));
  };

  const setClassBg = (subclass: string, base64: string) => {
    setClassBgsState(prev => ({ ...prev, [subclass]: base64 }));
  };

  const updateClassData = (subclass: string, data: Partial<ClassData>) => {
    setClassesDataState(prev => ({
      ...prev,
      [subclass]: {
        ...prev[subclass],
        ...data
      }
    }));
  };

  // SAVE ALL TO localStorage
  const saveChanges = () => {
    try {
      setItem("logo_sekolah", logoSekolah);
      setItem("logo_angkatan", logoAngkatan);
      setItem("bg_generation_hero", generationBg);
      setItem("generation_portrait", generationPortrait);
      setItem("generation_hero_text", generationHero);
      setItem("generation_docs", generationDocs);
      setItem("generation_achievements", generationAchievements);

      // Save each class page content
      Object.keys(classesData).forEach(subclass => {
        const stripped = cleanSubclassCode(subclass);
        const logoKey = `logo_class_${stripped}`;
        const bgKey = `bg_class_${stripped}_hero`;
        const dataKey = `class_data_${stripped}`;

        if (classLogos[subclass]) {
          setItem(logoKey, classLogos[subclass]);
        }
        if (classBgs[subclass]) {
          setItem(bgKey, classBgs[subclass]);
        }
        setItem(dataKey, classesData[subclass]);
      });

      setEditMode(false);
      showToast("Tersimpan secara aman!", "success");
    } catch (e) {
      console.error(e);
      showToast("Gagal menyimpan data.", "error");
    }
  };

  // DISCARD CHANGES
  const discardChanges = () => {
    loadFromStorage();
    setEditMode(false);
    showToast("Perubahan dibatalkan", "success");
  };

  return (
    <DataContext.Provider value={{
      editMode,
      setEditMode,
      logoSekolah,
      setLogoSekolah,
      logoAngkatan,
      setLogoAngkatan,
      generationBg,
      setGenerationBg,
      generationPortrait,
      setGenerationPortrait,
      generationHero,
      setGenerationHero,
      generationDocs,
      setGenerationDocs,
      generationAchievements,
      setGenerationAchievements,
      classLogos,
      setClassLogo,
      classBgs,
      setClassBg,
      classesData,
      updateClassData,
      saveChanges,
      discardChanges,
      toast,
      showToast,
      hideToast
    }}>
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error("useData must be used within a DataProvider");
  }
  return context;
};
